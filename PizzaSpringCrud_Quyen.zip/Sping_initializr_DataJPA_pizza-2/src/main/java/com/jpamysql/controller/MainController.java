package com.jpamysql.controller;


import java.util.Date;
import java.util.List;
import java.util.Random;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

//import com.jpamysql.data.Employee;
import com.jpamysql.data.Pizza;
//import com.jpamysql.repository.EmployeeRepository;
import com.jpamysql.repository.PizzaRepository;

 

@Controller
public class MainController {

//   @Autowired
//   private EmployeeRepository employeeRepository;
   @Autowired
   private PizzaRepository pizzaRepo ;
 

   private static final String[] NAMES = new String[] { "Tom", "Jerry", "Donald" };

   @ResponseBody
   @RequestMapping("/")
   public String home() {
       String html = "";
       html += "<ul>";
       html += " <li><a href='/showAllPizza'>Show All Pizza with Jsp pages</a></li>";
     
       html += "</ul>";
       return html;
   }

 
   @RequestMapping("/showAllPizza")
   public String showAllPizza(Model model) {

       
	   System.out.println( "------------- liste des pizzas ---------------------");
       for (Pizza pizza :  pizzaRepo.findallPizza()) {
           System.out.println( pizza.getId() );
       }

       model.addAttribute("pizzas", pizzaRepo.findallPizza());
		return "PizzaListView";
   }
   
   @PostMapping("/addPizza")
	public String addPizza(Model model) {
		pizzaRepo.addPizza();
		return "redirect:showAllPizza";
	}
   
   
   @RequestMapping("/removePizza/{id}")
	  public   String removeOnePizza(Model model, @PathVariable  int id) {   
		
	   System.out.println( "------------- delete une pizza ---------------------");
	   pizzaRepo.deletePizzaNo(id);
	   System.out.println(" pizza détruite " );
	   return "redirect:showAllPizza";
				
	   }
   
//   @RequestMapping("/showonePizzajstl/{id}")
//	  public    String showOnePizza(Model model, @PathVariable  int id) {   
//		
//	   System.out.println( "------------- recup une pizza ---------------------");
//	   Pizza pizza = pizzaRepo.findByPizzaNo(id);
//	   System.out.println( pizza.getId() );
//	   
//	    model.addAttribute("pizza", pizza);
//		return "PizzaOneView";
				
//	   }
   
   
   
   
   /**************************************************************************************/
   
   
   

}