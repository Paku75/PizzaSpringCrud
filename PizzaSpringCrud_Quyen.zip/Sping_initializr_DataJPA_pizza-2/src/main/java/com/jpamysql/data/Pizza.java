package com.jpamysql.data;

 
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity @Table( name="T_pizza" )
public class Pizza {

	@Id @GeneratedValue( strategy=GenerationType.IDENTITY )
    private int id;
	
	@Column(name = "Designpizz", length = 30, nullable = false)
    private String DesignPizz;
   
    @Column( name="Tarifpizz" )
    private double price;

	public int getId() {
		return id;
	}

	public Pizza() {
		super();
	}

	@Override
	public String toString() {
		return "Pizza [id=" + id + ", DesignPizz=" + DesignPizz + ", price=" + price + "]";
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDesignPizz() {
		return DesignPizz;
	}

	public void setDesignPizz(String designPizz) {
		DesignPizz = designPizz;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public Pizza(  String designPizz, double price) {
		super();
		 
		DesignPizz = designPizz;
		this.price = price;
	}
}