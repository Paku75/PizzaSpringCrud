package com.jpamysql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpingInitializrDataJpaPizza2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpingInitializrDataJpaPizza2Application.class, args);
	}

}
