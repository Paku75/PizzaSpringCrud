package com.jpamysql.repository;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.jpamysql.data.Pizza;

 
@Repository
public class PizzaRepository   {

	@Autowired
	   EntityManager entityManager;
	
	
	 
	
	public List<Pizza> findallPizza() {
		System.out.println( "- Lecture de tous les pizza -----------" );
        
        List<Pizza> pizzas = entityManager.createQuery( "from Pizza", Pizza.class ).getResultList();
        for (Pizza pizza : pizzas) {
            System.out.println( pizza );
            System.out.println( pizza.getId() );
            System.out.println( pizza.getPrice() );
            System.out.println( pizza.getDesignPizz() );
        }
        return pizzas ;
	}
	
	public void addPizza() {
		entityManager.createNativeQuery("INSERT INTO pizza (NroPizz, DesignPizz, TarifPizz) VALUES (?,?,?) ")
			.setParameter(1,pizza.getId())
			.setParameter(2,pizza.getDesignPizz())
			.setParameter(3,pizza.getPrice())
			.executeUpdate();
	}
	
	
	public Pizza findByPizzaNo(int PizzaNo) {
		  Pizza pizza =   entityManager.find(Pizza.class, PizzaNo);
		  System.out.println( pizza );
          System.out.println( pizza.getId() );
          System.out.println( pizza.getPrice() );
          System.out.println( pizza.getDesignPizz() );
		  return pizza;
	}
	

	public void deletePizzaNo(int PizzaNo) {
		 Pizza pizza =   entityManager.find(Pizza.class, PizzaNo);
		  System.out.println( pizza );
          System.out.println( pizza.getId() );
          System.out.println( pizza.getPrice() );
          System.out.println( pizza.getDesignPizz() );
          entityManager.remove(pizza);
	}
} 
